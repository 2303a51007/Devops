const express = require("express");
const bcrypt = require("bcrypt");

const app = express();
const PORT = 3000;

app.use(express.json());

// Demo user
const user = {
    username: "admin",
    passwordHash: bcrypt.hashSync("admin123", 10)
};

// Home
app.get("/", (req, res) => {
    res.send("Student API Server is running!");
});

// Login
app.post("/login", async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).json({
            message: "Username and password are required"
        });
    }

    if (username !== user.username) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    const validPassword = await bcrypt.compare(
        password,
        user.passwordHash
    );

    if (!validPassword) {
        return res.status(401).json({
            message: "Invalid username or password"
        });
    }

    res.json({
        message: "Login successful",
        username: username
    });
});

// Students
app.get("/students", (req, res) => {
    res.json([
        {
            id: 1,
            name: "Bharath",
            rollNumber: "23CS001",
            email: "bharath@example.com",
            department: "CSE",
            year: 3,
            course: "Computer Science"
        },
        {
            id: 2,
            name: "Srinivas",
            rollNumber: "23CS002",
            email: "srinivas@example.com",
            department: "CSE",
            year: 3,
            course: "Computer Science"
        }
    ]);
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});